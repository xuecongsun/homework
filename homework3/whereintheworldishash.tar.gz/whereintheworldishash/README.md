#README for printcap3.sh
## Authour: Emma Sun xs58
### Explanation:
The user can pass in an argument to this bash script. If the argument is a directory, this script will print out all file names and change any capital letter in the file name to 3 times of the capital letter. If the argument is not a directory, an error message will be printed into printcap3_error.log
