#!/bin/bash


if [[ -d "$1" ]]; then var=`(ls "$1")`; echo "$var"|sed 's/[A-Z]/&&&/g'; else touch printcap3_error.log;echo "Not a directory" > printcap3_error.log; fi

